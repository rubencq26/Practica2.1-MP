package libClases;

public interface Proceso {
    public abstract boolean equals(Object obj);
    void ver();
}